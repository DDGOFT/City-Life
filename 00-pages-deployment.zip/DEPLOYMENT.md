# 1.0候选部署与回退

唯一仓库DDGOFT/City-Life，保留用户已启用的Actions Pages及/City-Life/网址。完整源码根入口引用dist；独立部署ZIP将dist完整平铺为静态根，必须包括assets、JS、CSS、sw.js，不能只传HTML。无npm在线运行依赖，HTTPS部署后缓存支持离线，首次必须完整下载。

源码ZIP包含完整工程与Git历史文本，另外交付独立version-history.bundle（避免在ZIP里重复占用约30MB）。需要恢复Git历史时，下载bundle并使用下列命令；仅构建源码不需要Git数据库。恢复：

```sh
git clone version-history.bundle City-Life
cd City-Life
git remote set-url origin https://github.com/DDGOFT/City-Life.git
npm ci --include=dev
npm run build
npm test
npm run check
npm run simulate
git fetch origin
git push origin main --tags backup/v0.5-local
```

必须先检查远端历史是否新增。若不同，合并并回归，禁止强推覆盖。`.github/workflows/pages.yml`验证完整源码与构建产物一致，已保留用户启用的deploy-v05.yml入口，升级为npm构建/测试/模拟后上传dist并由deploy-pages发布。当前连接写入403，不保证这些命令在无权限环境成功；需要仓库contents和workflow写权限。发布成功须核对main/Pages SHA及实际线上资源，再运行GAME_URL线上浏览器回归。

回退点v0.5-live/backup/v0.5-live保留实际线上8901092（构建8a4e47f8d57d），v0.5-stable-local对应完整旧源码f59eba6；v0.4-live对应原线上入口ed071a1；原有标签/历史都保留。回退用新提交恢复指定版本，保留新增挑战槽的导出备份。v0.5本身没有debt模式，不能读取debt挑战档，但仍可读取原有沙盒/旧挑战；禁止清空数据库“修复”这一情况。新版本保留旧存档固定快照，回退前先手动导出全部当前档。
