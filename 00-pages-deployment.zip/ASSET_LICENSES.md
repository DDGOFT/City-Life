# 城市人生素材授权清单 · 1.0候选

全部运行资源由仓库内相对路径提供；不使用《大多数》资产或来源不明的商业人物/动画。资源精确字节、SHA-256见`docs/v1.0/resource-manifest.json`，PBR下载URL与原始/衍生大小见`docs/PBR-SOURCES.json`。

| 资源 | 明确来源 / 许可 | 当前使用、修改与大小 |
|---|---|---|
| 人体基础网格 | [MakeHuman base.obj](https://github.com/makehumancommunity/makehuman/blob/master/makehuman/data/3dobjs/base.obj)，©2020 Data Collection AB、Joel Palmius、Jonas Hauquier；文件头及[仓库资产许可](https://github.com/makehumancommunity/makehuman/blob/master/LICENSE.ASSETS.md)明确CC0 | 只用`body`网格，去除辅助形体；归一化到约1.76m，材质服装分区与轮廓加宽、原创短发和眼睛、原创骨骼权重与动作。原始数据在art-source/characters，不引入MakeHuman AGPL程序代码。 |
| citizen-standard.glb / citizen-low.glb | 上述CC0基础网格的本项目衍生资源；基础数据CC0，原创脚本MIT | 401,260 / 317,532 B；body约7,490 / 4,548三角形（以导出日志/网格统计为准），含Idle、Walk、Talk、Phone、Sit及Carry、Lift、Place、Clean、Serve、Operate共十一个原创动作，不来自Mixamo/商业游戏。服装目前为基础材质与网格轮廓，仍不是独立高质量衣物资产。 |
| street-kit.glb | 本项目原创，MIT；源脚本scripts/generate-street-kit.py | 含店屋、电动车、自行车、果蔬摊、长椅、护栏、配电箱、花箱。店屋为开放门面、窗框/阳台/空调/雨棚/晾衣的模块化网格；不是照片扫描建筑。精确大小见manifest。 |
| asphalt_02 / brick_wall_003 / concrete_pavement / blue_plaster_weathered | [Poly Haven](https://polyhaven.com/)四套资源；[官方许可](https://polyhaven.com/license)CC0 | 分别用于旧沥青、砖墙、人行铺装、风化灰泥。颜色、OpenGL法线、粗糙度各一张，共12张，1k源图缩至512×512 JPEG，质量85；移动低画质只绑定颜色图。作者及来源元数据保留于docs/PBR-SOURCES.json及下载链接。 |
| 原创城市资源库 city-kit.glb | 本项目原创，MIT；scripts/generate-city-kit.py | 商业楼、仓库、社区楼、床/柜/桌/沙发/厨卫、货车/叉车/手推车、餐盘/纸箱/文件夹/扫帚/工具箱/树；精确字节和网格预算见manifest/导出日志。材质复用已有CC0 PBR，无新增第三方资产。 |
| 合成环境声与反馈音 | src/systems/soundscape.js、main.js本项目原创，MIT | 四区不同的滤波底噪、机械/音调/鸟鸣和公告栏距离衰减音调，以及劳动/收入等反馈；运行时生成，不需要音频文件。没有真实人声、叫卖对白、商场广播或实录素材，不能宣称已有这些真实音效。旧ambience.js保留为历史实现。 |
| 招牌、告示文字 | 本项目原创Canvas绘制，MIT | 使用设备字体，无分发第三方字体。店名沿用已有原创内容，不复制参考游戏招牌。 |
| Three.js与GLTFLoader/SkeletonUtils/BufferGeometryUtils | Three.js r170，MIT | vendored在src/vendor；完整MIT许可同时放在public/assets/licenses/THREE-LICENSE.txt。 |
| CesiumMan旧版衍生模型 | ©2017 Cesium，CC BY 4.0 | v0.4历史资源留在backups/v0.4/assets及稳定Git标签，v0.5正常运行不再加载。原授权记录保留，不能替代本表。 |

完整CC0文本：public/assets/licenses/MakeHuman-CC0.txt。MakeHuman许可解释存于docs/licenses/MakeHuman-LICENSE.md。原创代码遵循根LICENSE的MIT许可。开发依赖与浏览器工具的许可证在相应npm包内，不分发node_modules。

可重现美术导出：Blender 4.3.2运行generate-character、generate-street-kit和generate-city-kit脚本；纹理重建使用Python + Pillow运行download-textures.py。普通npm构建直接复制已有授权资源，不需要Blender或下载网络素材。

临时/质量差距：四区已使用不同原创模块建筑与树木，仍有模板重复与简化的公共设施；衣物、头发轮廓、皮肤/表情与动画为基础版本；没有动作捕捉、服装模拟、面部表情库或完整实景环境声。不能据此宣称达到《大多数》的商业美术品质。
