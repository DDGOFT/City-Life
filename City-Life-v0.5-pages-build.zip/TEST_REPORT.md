# v0.5测试报告 · 2026-10-14

构建：0.5.0 / 8a4e47f8d57d。**未同步GitHub、未部署v0.5。** CLI推送、REST创建稳定引用及已连接GitHub工具写入均返回403 Resource not accessible by integration。远端main与Pages仍为ed071a1，线上HTML经字节校验仍完全等于原v0.4。当前账号可读，但集成写权限不可用。全部v0.5结果为本地源码/部署包验证；GitHub CI未运行，线上v0.5浏览器验证未运行。详见docs/v0.5/deployment-results.json。

## 自动化与旧档兼容

**96/96项Node测试通过**。覆盖原有16职业、经济、物品/培训/住房、16 NPC与事件、两剧情多结局、存档事务及原有场景/导航，以及新增v0.4三模式封包、固定current/previous备份、v0.3备份保留、共享道具碰撞/所有入口可达、日程活动、光照、后台恢复、LOD导航保留、真实GLB预算/五动作、512px照片材质及腕部/骨骼释放。原始记录：docs/v0.5/node-tests.txt。另在没有.git的干净源码解压目录中，npm ci（离线开发缓存）、build、96项test与check全部通过，构建指纹相同；见plain-archive-tests.txt及plain-archive-check.txt。

引擎源码与v0.4只差导入路径；数据库仍city-life-v1，slots和schemaVersion2不变。构建/路径/JS语法、实际资源、核心规则原文与可重复构建检查通过，见static-check.json及resource-manifest.json。新碰撞若覆盖极少数旧坐标，沿用安全位置校正，原封包固定保留。开发/浏览器测试使用隔离数据库，不接触用户手机存档。

## 实际浏览器、场景与缓存

Linux Chromium 154.0.8037.57：Pages根布局与dist独立布局均通过实际WebGL、GLB/PBR完整加载、v0.4继续、保存重开、旧封包完整保留、小地图/完整地图、真实CDP双指事件、拖动/筛选/标记/路线移动及三档LOD切换。390×844 CSS px，触控/移动仿真；HUD高度约95.8px、小地图82px。不是iPhone或安卓真机。详见browser-results.json与browser-log.txt。

8个场景/时段夹具：四区、室内、白天/黄昏/夜晚。所有换场后的GPU贴图释放断言归零；这不是完整生活流程/真机长时测试。见render-results.json及old-facade/dusk/night/interior/shopfront图片。

缓存测试PASS：完整预缓存、等待Worker、保存后激活刷新、清理旧资源缓存、离线恢复HTML/JS/GLB/PBR与同一IndexedDB存档。localhost安全上下文中显式注册Worker；不冒充iOS微信缓存测试。见cache-results.json。

## 性能实测与限度

Linux headless Chromium, SwiftShader software GPU, 390x844 DPR2; not a physical mobile device。每档约3秒短样本，DPR2环境下低/中/高实际渲染倍率分别1/1.5/2；低关闭阴影与法线/粗糙度采样、采用低面数模型，中/高影子512/1024。真实显卡标识见environment.json。

| 画质 | 样本 | 实测FPS | 绘制调用 / 三角形 | 人物LOD |
|---|---|---:|---:|---|
| low | 3.083 s / 25帧 | 8.11 | 66 / 40304 | low |
| medium | 3.400 s / 7帧 | 2.06 | 66 / 49130 | standard |
| high | 3.450 s / 5帧 | 1.45 | 66 / 49130 | standard |

这是**软件渲染**观测，未达到手机稳定30/60 FPS的证据标准。中高画质在此环境明显更慢，不能承诺手机流畅。FPS统计排除冻结菜单背景；移动步长仍上限50ms，避免长帧瞬移，极低帧环境模拟也会减慢。

## 未验证与已知美术差距

- 真实iPhone Safari、iOS/安卓微信、安卓Chrome设备；安全区/键盘/大字号、关闭重开、后台/多标签更新、温升与长期FPS。
- Safari/WebKit桌面未成功运行（现有环境缺系统依赖）；Chromium仿真不能替代Safari。
- 骨骼动作没有足部IK/根运动、完整握物/表情；服装与短发仍是基础资源，NPC共用通用基础脸型。
- 老街为原创模块店屋配实拍PBR，仍有重复、简化室内和玻璃反射差距；其他三区、树木、部分设施/住房室内仍沿用临时几何。
- 环境声是合成，不是实录。没有达到《大多数》的商业美术/动画品质。

后续优先真机三档调优、更多服装/脸型和独立衣物、脚底接触/交互、树木及店屋变体，再复用至其他三区。继续使用现有src/public正式工程，不重建演示版。
